bhcl:
this app is made for amazon fire tablets, if you have a non-amazon device; i cannot gurantee that it will work.

Made with:
ADB,
Automate,
My own custom flows (for automate),
 AND
My batch coding (source code will be out soon.)

Story behind it:
Sooo i wanted to get a custom launcher but NONE of the custom launchers worked so i made my own to my needs 
1. it needs to be fast
